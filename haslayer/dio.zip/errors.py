"""Errors for the HLK-DIO16 component."""
from homeassistant.exceptions import HomeAssistantError


class DIO16Exception(HomeAssistantError):
    """Base class for HLK-DIO16 exceptions."""


class CannotConnect(DIO16Exception):
    """Unable to connect to the HLK-DIO16."""
