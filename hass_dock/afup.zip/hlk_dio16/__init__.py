"""HLK-dio16 Protocol Support."""
from hlk_dio16.protocol import create_hlk_dio16_connection # noqa
