#!/usr/bin/env python

from setuptools import setup

setup(
        name='hlk-dio16',
        version='0.0.1',
        description='Python client for HLK-dio16',
        url='https://github.com/ayang/hlk-dio16',
        author='Bruce yang',
        author_email='ayang23@gmail.com',
        license='MIT',
        packages=[
            'hlk_dio16',
            ],
        )
